<html lang="en">

  <head>

    <?php
      include_once 'head.php';
    ?>
    <style>
    p img {
      margin: auto;
      padding: auto;
      width: 65%;
      height: auto;
    }
    </style>
  </head>

  <body>

    <!-- Navigation -->

    <?php
      include_once 'navbar.php';
    ?>
<br>
<br>
  <div class = "container">
    <!-- Page Content -->
    <div class="container" style = "padding-top:70px;">
      <h2 style = "font-family: Verdana; text-align: center;"> Contact </h2>
      <hr>
      <br>
      <p style = "font-family: Verdana; text-align: center; font-size: 16px;">
        Have any questions or concerns? Feel free to contact us at support@streamrally.com. Our services are available during the day from 9-5 p.m ET. </p>
     <p style = "text-align: center;">
     <img src = "images/contactPic1.png" />
   </p>
    </div>
  </div>
    <!-- /.container -->
<br>
<br>
    <!-- Footer -->
    <?php
      include_once 'footer.php';
      ?>


  </body>

</html>
