<?php

$db_user = "root";
$db_pass = "Cycling55";
$db_name = "streamrally";
$db_host = "localhost";

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
